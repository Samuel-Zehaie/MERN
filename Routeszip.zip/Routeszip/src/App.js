import './App.css';
import {
  Routes,
  Route,
  Link,
  Navigate
}
  from 'react-router-dom';
import Welcome from './components/Welcome';
import Num from './components/Num';



function App() {
  return (
    <div className="App">
      {/* <Link to="/">Go Home</Link>
      <Link to={"/cool/hero"}>hero page</Link> */}
  


      <Routes>

        <Route path="/" element={<Navigate to="/home" />}/>

        <Route path="/home" element={<h1>Welcome</h1>}/>
        
        <Route path="/:num/:blue/:red" element={<Num />} />
        
        <Route path="/:word" element={<Welcome />} />
        






        <Route path="*" element={<p>404 not found </p>}/>





      </Routes>
    </div>
  );
}

export default App;
