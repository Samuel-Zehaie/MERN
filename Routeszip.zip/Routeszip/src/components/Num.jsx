import React from 'react'
import { useParams } from 'react-router-dom'

const Num = (props) => {
    //grab the variable from the URL

    const { num } = useParams();

    const { blue } = useParams()

    const { red } = useParams();



    return (
        <div style= {{backgroundColor: blue, color: red}}>The word is:  {num}</div>
)
}

export default Num