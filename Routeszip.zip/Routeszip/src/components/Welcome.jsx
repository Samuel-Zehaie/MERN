import React from 'react'
import { useParams } from 'react-router-dom'

const Welcome = (props) => {

    const { word } = useParams();

    const isNumber = !isNaN(word)


    return (
        <div>

            <div>{isNumber ? <div> The Number is: {word} </div> :
                <div >The Word is :{word} </div>}
            </div>
        </div>
    )
}

export default Welcome