import React from 'react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';


const Update = () => {

    const navigate = useNavigate()

    const { id } = useParams()
    
    const [author, setAuthor] = useState("")
    
    useEffect(() => {
        axios.get("http://localhost:8000/api/authors/" + id)
            .then(res => {
                console.log(res.data);
                //set all inputs from the db
                setAuthor(res.data.author)

            })
            .catch(err => console.log(err));


    }, [id])

    const SubmitAuthor = (e) => {
        e.preventDefault();
        console.log("cool");
        const tempSendToDB = {
            author
        };


        
        axios.patch(`http://localhost:8000/api/authors/${id}`, tempSendToDB)
            .then(res => {
                console.log("✅✅", res.data);
                navigate("/");
            })
            .catch(err => 
                console.log("❌❌", err));
                
    };



    return (
        <div>Favorite authors
                        <Link to="/">Home</Link>

    <div>Add a new author</div>

    <form onSubmit={SubmitAuthor} style={{border:"1px solid black", width:'fit-content', margin: '0 auto'}}>
        <div>
            <label>Name:</label>
        </div>
        <div>
            <input type="text" value={author} onChange= {e => setAuthor(e.target.value)} />
        </div>
        <Link  to="/" style={{backgroundColor:"blue", color: "white", marginTop: "10px"}}>Cancel</Link>
        <button style={{backgroundColor:"blue", color:"white"}}>Submit</button>




</form>







        </div>
    )
}

export default Update