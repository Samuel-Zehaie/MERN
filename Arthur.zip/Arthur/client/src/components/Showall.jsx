import React from 'react'
import axios from 'axios';
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const Showall = () => {
    const [authors, setAuthors]= useState([])

    useEffect(() => {
        axios.get("http://localhost:8000/api/authors")
            .then(res => {
                console.log(res.data)
                setAuthors(res.data)
            })
            .catch(err => {
                console.log(err);
            });

    }, []);

    const deleteMe = (deleteId) => {
        console.log("delete", deleteId);
        axios.delete(`http://localhost:8000/api/authors/${deleteId}`)
            .then(res => {
                console.log(res.data);
                const filteredauthor = authors.filter((author) => {
                    return author._id !== deleteId;
                });
                setAuthors(filteredauthor);
                
            })
            .catch(err => console.log(err));

    };
    return (
        <div>Favorite authors
            <div>
                <Link to="/authors/new">Add an Author</Link>
            </div>
            
            {/* {JSON.stringify(authors)} */}

            {authors.map((author) => {
                return <div key={author._id}>
                    {author.author}
                    <Link to={ `/authors/${author._id}/edit`}>Edit</Link>
                    <button onClick={() => deleteMe(author._id)}>Delete</button>
                    </div>
            })}



        </div>
    )
}

export default Showall