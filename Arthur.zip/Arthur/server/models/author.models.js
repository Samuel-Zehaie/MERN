const mongoose = require('mongoose');

const AuthorSchema = new mongoose.Schema({
    author: {
        type: String,
        required: [true, "author is required"],
        minLength: [3,'author must have at least 3 characters']
    },
    // price: {
    //     type: Number
    // },
    // description: {
    //     type: String
    // }
},{timestamps: true});

const Author = mongoose.model('Author', AuthorSchema);

module.exports = Author;
