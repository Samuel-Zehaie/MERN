import logo from './logo.svg';
import './App.css';
import { Routes, Route, Link } from "react-router-dom";
import Showall from './components/Showall';
import Create from './components/Create';
import Update from './components/Update';
import { Navigate } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      

      <Routes>
      <Route path="/" element={<Navigate to="/authors" />} />  

      <Route path="/authors" element={<Showall />} />

      <Route path="/authors/new" element={<Create />} />

      <Route path="/authors/:id/edit" element={<Update />} />
    
      </Routes>
    </div>
  );
}

export default App;
