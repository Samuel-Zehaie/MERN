import React from 'react'
import { Link } from 'react-router-dom';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';


const Create = () => {

    const navigate = useNavigate();

    const [author, setAuthors] = useState("")

    //Create an array to store errors from the API
    const [errors, setErrors] = useState([])
    
    const SubmitAuthor = (e) => {
        e.preventDefault();
        console.log('submit')
        const tempSendToDB = {
            author
        }


        axios.post("http://localhost:8000/api/authors", tempSendToDB)
        .then(res => {
            console.log("✅✅", res.data);
            navigate("/");
        })
            .catch(err => {
                console.log("❌❌", err)
                const errorResponse = err.response.data.errors; // Get the errors from err.response.data
                const errorArr = []; // Define a temp error array to push the messages in
                for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
                    errorArr.push(errorResponse[key].message)
                }
                // Set Errors
                setErrors(errorArr);
        }
        );
    }


    return (
        <div>Create
            <Link to="/">Home</Link>

            <div>Add a new author</div>

            <form onSubmit={SubmitAuthor} style={{ border: "1px solid black", width: 'fit-content', margin: '0 auto' }}>
            {errors.map((err, index) => <p key={index}>{err}</p>)}
                <div>
                    <label>Name:</label>
                </div>
                <div>
                    <input type="text" value={author} onChange= {e => setAuthors(e.target.value)} />
                </div>
                <Link  to="/" style={{backgroundColor:"blue", color: "white", marginTop: "10px"}}>Cancel</Link>
                <button style={{backgroundColor:"blue", color:"white"}}>Submit</button>




            </form>

        </div>
    )
}

export default Create