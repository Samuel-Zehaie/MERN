const user = require("../controllers/user.controller")
console.log("***", user)
const company = require("../controllers/company.controller")

module.exports = app => {


    app.get("/api/users/new", user.createNewUser);

    app.get("/api/companies/new", company.createNewCompany);

    // app.get("/api/users/company", [user.get, company.get])

}