//import the mongoose lib to build the schema

const mongoose = require('mongoose');

//the model - the rules the entries need to follow

const JokeSchema = new mongoose.Schema({
    setup: {
        type: String,
        required: [true, "Setup is required"],
        minlength: [2, "Setup must be at least 2 characters long "]
    },
    punchline: {
        type: String,
        required: [true, "Punchline is required"],
        minlength: [2, "punchline must be at least 2 characters long"]
    }
    
}, {timestamps: true});

const Joke = mongoose.model('Joke', JokeSchema);

module.exports = Joke;
