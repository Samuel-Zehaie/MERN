
import './App.css';
import { Routes, Route, Link } from 'react-router-dom';
import Form from './components/Form';
import Allproducts from './components/Allproducts'
import Oneproducts from './components/Oneproducts';
import Update from './components/Update';


function App() {
  return (
    <div className="App">
      <Link to="/">Home</Link>
      <Routes>
        
        {/*Read all */}
      <Route path="/" element={<Form />} />

        {/*Read one */}
        <Route path="/products/:id" element={<Oneproducts />} />
        
        {/*Update */}
        <Route path="/:id/edit" element={<Update />} />


      </Routes>
  
    </div>
  );
}

export default App;
