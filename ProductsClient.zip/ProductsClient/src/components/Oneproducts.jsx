import React from 'react'
import { useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';


const Oneproducts = (props) => {

    const navigate = useNavigate()

    const { id } = useParams();
    const [oneproduct, setOneProduct]= useState(null)
    
    useEffect(() => {
        axios.get("http://localhost:8000/api/products/" + id)
            .then(res => {
                console.log(res.data);
                setOneProduct(res.data)
            })
            .catch(err => console.log(err));


    }, [id])
    
    const deleteOne = (id) => {
        console.log("delete", id);
        axios.delete(`http://localhost:8000/api/products/${id}`)
            .then(res => {
                console.log(res.data)
                navigate("/")
            })
            .catch(err => console.log(err));

    };

    return (
        <div> 

            {
                oneproduct ? (
                    <div key={id}>
                        <h2>{oneproduct.title}</h2>
                        <h2>{oneproduct.price}</h2>
                        <h2>{oneproduct.description}</h2>
                        <button onClick={() => deleteOne(id)}>delete</button>
                    </div>
                    

                ) : <h3>Loading....</h3>
            
            }


        </div>
    )
}

export default Oneproducts