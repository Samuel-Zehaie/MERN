import React from 'react'
import { useParams } from 'react-router-dom'
import { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Update = (props) => {
    const navigate = useNavigate();

    const { id } = useParams()
    const [title, setTitle] = useState("");
    const [price, setPrice] = useState("");
    const [description, setDescription] = useState("");
    
    useEffect(() => {
        axios.get("http://localhost:8000/api/products/" + id)
            .then(res => {
                console.log(res.data);
                //set all inputs from the db
                setTitle(res.data.title)
                setPrice(res.data.price)
                setDescription(res.data.description)
                
            })
            .catch(err => console.log(err));


    }, [id])

    const submitProduct = (e) => {
        e.preventDefault();
        console.log("cool");
        const tempSendToDB = {
            title,
            price,
            description
        };
        // setTitle("")
        // setPrice("")
        // setDescription("")

        
        axios.patch(`http://localhost:8000/api/products/${id}`, tempSendToDB)
            .then(res => {
                console.log("✅✅", res.data);
                navigate("/");
            })
            .catch(err => 
                console.log("❌❌", err));
                
    };


    return (
        <div>
                    <form onSubmit={submitProduct}>
            <div>
                <label >Title:</label>
                <input type="text" value={title} onChange= {e => setTitle(e.target.value) } />
            </div>
            <div>
                <label>Price:</label>
                <input type="number" value={price} onChange= {e => setPrice(e.target.value) }/>
            </div>
            <div>
                <label>Description:</label>
                    <input type="text" value={description} onChange= {e => setDescription(e.target.value)} />
            </div>
            <div>
                <button>Create</button>
            </div>
        </form>





        </div>
    )
}

export default Update;