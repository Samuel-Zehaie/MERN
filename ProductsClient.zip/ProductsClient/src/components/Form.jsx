import React from 'react'
import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Allproducts from './Allproducts';


const Form = (props) => {
    const navigate = useNavigate();

    const [title, setTitle] = useState("");
    const [price, setPrice] = useState("");
    const [description, setDescription] = useState("");
    const [isImportant, setIsImportant] = useState(false);
    

//Create an array to store errors from the API
    const [errors, setErrors] = useState([])

    const [submit, setSubmit] = useState(true)

    const submitProduct = (e) => {
        e.preventDefault();
        console.log("cool");
        const tempSendToDB = {
            title,
            price,
            description,
            isImportant
        };
        // setTitle("")
        // setPrice("")
        // setDescription("")

        
        axios.post("http://localhost:8000/api/products", tempSendToDB)
            .then(res => {
                console.log("✅✅", res.data);
                setSubmit(!submit);
            })
            .catch(err => {
                console.log("❌❌", err)
                const errorResponse = err.response.data.errors; // Get the errors from err.response.data
                const errorArr = []; // Define a temp error array to push the messages in
                for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
                    errorArr.push(errorResponse[key].message)
                }
                // Set Errors
                setErrors(errorArr);
            }
        );
        setTitle("")
        setPrice("")
        setDescription("")
    };


    return (
        <div>
            Product Manager

            
            <div>
                {/* {JSON.stringify(title)}
                {JSON.stringify(price)}
                {JSON.stringify(description)}
                {JSON.stringify(isImportant)} */}
            </div>
            <form onSubmit={submitProduct}>
            {errors.map((err, index) => <p key={index}>{err}</p>)}
            <div>
                <label >Title:</label>
                <input type="text" value={title} onChange= {e => setTitle(e.target.value) } />
            </div>
            <div>
                <label>Price:</label>
                <input type="number" value={price} onChange= {e => setPrice(e.target.value) }/>
            </div>
            <div>
                <label>Description:</label>
                    <input type="text" value={description} onChange= {e => setDescription(e.target.value)} />
                </div>
                
                <div>
                    content:
                    <textarea></textarea>
            </div>
            <div>
                    <input type="checkbox" checked={isImportant} onChange ={e => setIsImportant(e.target.checked)} /> important?
            </div>
            <div>
                <button>Create</button>
            </div>
            </form>
            <Allproducts submit={submit} />

        </div>
    )
}

export default Form