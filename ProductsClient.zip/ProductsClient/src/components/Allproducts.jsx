import React from 'react'
import { useEffect, useState } from 'react'
import axios from 'axios'
import { json } from 'react-router-dom'
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

const Allproducts = (props) => {

    const navigate = useNavigate();

    const [products, setProducts] = useState([])
    
    useEffect(() => {
        axios.get("http://localhost:8000/api/products")
            .then(res => {
                console.log(res.data)
                setProducts(res.data)
            })
            .catch(err => {
                console.log(err);
            });

    }, [props.submit]);

    const deleteMe = (deleteId) => {
        console.log("delete", deleteId);
        axios.delete(`http://localhost:8000/api/products/${deleteId}`)
            .then(res => {
                console.log(res.data);
                const filteredProduct = products.filter((oneProduct) => {
                    return oneProduct._id !== deleteId;
                });
                setProducts(filteredProduct);
                
            })
            .catch(err => console.log(err));

    };



    return (
        <div>
                <h1>All Products</h1>

            {/* {JSON.stringify(products)} */}

            
            {products.map((product) => {
                return <div key={product._id}>
                    <Link to={"/products/"+ product._id}>
                        {product.title}
                    </Link>
                    <br />
                    <Link to={`/${product._id}/edit` }>Update This Product</Link>
                    <br />
                        <button onClick={() => deleteMe(product._id)}>Delete</button>
                    
                        </div>
                })}



        </div>
    )
}

export default Allproducts