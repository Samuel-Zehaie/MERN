import './App.css';
import Api from './componenets/Api';
import { Routes, Route, Link } from "react-router-dom";
import People from './componenets/People';
import Planets from './componenets/Planets';
import Forms from './componenets/Forms';
import Error from './componenets/Error';


function App() {
  return (
    <div className="App">
      <Link to= '/'>Main Form Page</Link>

      <Routes>

        <Route path="/people/:num" element={<><People /> <Forms /></>} />
        

        <Route path="/planets/:num" element={<><Planets /> <Forms /></>} />

        <Route path= '/' element={<Forms />}/>

        <Route path="*" element={<p>error page</p>} />
        
        <Route path="/error" element= {<Error />}/>










      </Routes>

    </div>
  );
}

export default App;
