import React from 'react'
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Forms = () => {

    const navigate = useNavigate();
    // console.log(navigate);

    const [peoplenum, setPeopleNum] = useState(1);
    const [cat, setCat] = useState('people')



    const changepeople = (e) => {
        e.preventDefault();
        console.log(changepeople)
        // console.log('submit')
        //navigate to a route in our APP!
        navigate("/"+cat+"/"+ peoplenum)  ////(`/${cat}/${peoplenum}`)   another way of doing it using string inter
    }


    return (
        <div>Forms
            {JSON.stringify(peoplenum)}

            <form onSubmit={changepeople}>
            <label for ='people'>Search:</label>
                <select name='people' id='people' onChange = {e => setCat (e.target.value) }>
                    <option value='people'>People</option>
                    <option value='planets'>Planets</option>
                </select>
                <label>ID:</label>
                <input type="number" value={peoplenum} onChange={e => setPeopleNum(e.target.value)} />
                <div>
                    <button style={{backgroundColor: 'blue', color: 'white'}}>Search</button>
                </div>






            </form>







        </div>
    )
}

export default Forms