import React from 'react'
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';


const Planets = () => {
    //create state var to hold the people here
    const [planets, setPlanets] = useState(null)

    const navigate = useNavigate();

    // grab the variable from the URL

    const { num } = useParams();
    console.log(num)

    useEffect(() => {
        axios.get("https://swapi.dev/api/planets/" + num + "")
            .then(res => {
                console.log(res.data)
                setPlanets(res.data)
            })
            .catch(err => {
                console.log(err)
                navigate("/error")
            }
                );
    
    
    }, [num])


    return (
        <div>
            <h1>Planets</h1>

            {planets ? (
                <div>
                    <h2>{planets.name}</h2>
                    <div>
                        <p>Climate: {planets.climate}</p>
                    </div>
                    <div>
                        <p>Terrain: {planets.terrain}</p>
                    </div>
                    <div>
                        <p>Surface Water: {planets.surface_water}</p>
                    </div>
                    <div>
                        <p>Population: {planets.population}</p>
                    </div>
                </div>
            ) : (
                <h2>Loading....</h2>
            )}
        </div>
    );
};

export default Planets