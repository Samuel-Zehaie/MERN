import React from 'react'
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const People = () => {
    //create state var to hold the people here
    const [people, setPeople] = useState(null)

    const navigate = useNavigate();

    // grab the variable from the URL

    const { num } = useParams();
        console.log(num)

    useEffect(() => {
        axios.get("https://swapi.dev/api/people/"+ num +"")
            .then(res => {
                console.log(res.data)
                setPeople(res.data)
            }) 
            .catch(err => {
                console.log(err)
                navigate ("/error")
        } 
    )
        
    },[num])
    
    return (
        <div>People

            {people ? (
                <div>
            
                    <h1>{people.name}</h1>
                    <div>
                        <p1>Height:{people.height}</p1>
                    </div>
                    <div>
                        <p1>Mass:{people.mass}</p1>
                    </div>
                    <div>
                        <p1>Hair Color:{people.haircolor}</p1>
                    </div>
                    <div>
                        <p1>Skin Color: {people.skincolor}</p1>
                    </div>
                </div>
            ) : (
                <h2>Loading.....</h2>
            )}



        </div>
    )
}

export default People