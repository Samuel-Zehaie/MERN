import React from 'react'

const Error = () => {
    return (
    <>
        <div>"These aren't the droids you're looking for</div>

            <img src="https://lumiere-a.akamaihd.net/v1/images/obi-wan-kenobi-main_3286c63c.jpeg?region=0%2C0%2C1280%2C721" alt="" />
    </> 
    )
}

export default Error